sub init()
    m.video = m.top.findNode("videoPlayer")
    m.status = m.top.findNode("statusLabel")

    m.video.observeField("state", "onPlaybackStateChange")

    m.clips = []
    m.clipIndex = 0

    m.status.text = "Finding clips..."
    m.status.visible = true

    m.top.setFocus(true)

    startFetch()
end sub

' -------------------------------------------------------------
' EDIT THIS: your GitHub username/repo to auto-scan for .mp4 files
' -------------------------------------------------------------
function getRepoApiUrl() as string
    return "https://api.github.com/repos/lelandlikemodz/tiktok-for-roku-test/contents/"
end function

sub startFetch()
    m.fetchTask = CreateObject("roSGNode", "ClipFetchTask")
    m.fetchTask.repoUrl = getRepoApiUrl()
    m.fetchTask.observeField("clips", "onClipsFound")
    m.fetchTask.observeField("errorMessage", "onFetchError")
    m.fetchTask.control = "RUN"
end sub

sub onClipsFound()
    clips = m.fetchTask.clips
    if clips = invalid or clips.count() = 0
        m.status.text = "No clips found."
        return
    end if

    m.clips = clips
    playClip(0)
end sub

sub onFetchError()
    msg = m.fetchTask.errorMessage
    if msg <> ""
        m.status.text = msg
        m.status.visible = true
    end if
end sub

sub playClip(index as integer)
    if index < 0 or index >= m.clips.count()
        return
    end if

    m.clipIndex = index
    clipUrl = m.clips[m.clipIndex]

    content = CreateObject("roSGNode", "ContentNode")
    content.url = clipUrl
    content.streamFormat = "mp4"
    content.title = "Clip " + stri(m.clipIndex + 1).trim()

    m.video.content = content
    m.video.visible = true
    m.video.control = "play"

    m.top.setFocus(true)

    m.status.text = "Playing clip " + stri(m.clipIndex + 1).trim() + " of " + stri(m.clips.count()).trim()
end sub

sub onPlaybackStateChange()
    state = m.video.state

    if state = "error"
        m.status.text = "Playback error on this clip."
        m.status.visible = true
    else if state = "playing"
        m.status.visible = false
    else if state = "finished"
        m.status.text = "Finished. Press OK to replay."
        m.status.visible = true
    end if
end sub

sub onKeyEvent(key as string, press as boolean) as boolean
    print "=== onKeyEvent: key="; key; " press="; press

    if not press
        return false
    end if

    if key = "OK"
        playClip(m.clipIndex)
        return true
    else if key = "down"
        playClip(m.clipIndex + 1)
        return true
    else if key = "up"
        playClip(m.clipIndex - 1)
        return true
    end if

    return false
end sub
