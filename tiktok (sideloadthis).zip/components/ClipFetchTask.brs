sub init()
    m.top.functionName = "runFetch"
end sub

sub runFetch()
    request = CreateObject("roUrlTransfer")
    if request = invalid
        m.top.errorMessage = "Could not create network object."
        return
    end if

    request.SetCertificatesFile("common:/certs/ca-bundle.crt")
    request.InitClientCertificates()
    request.SetUrl(m.top.repoUrl)
    request.AddHeader("User-Agent", "Roku-Channel")
    request.AddHeader("Accept", "application/vnd.github+json")

    response = request.GetToString()

    if response = invalid or Len(response) = 0
        m.top.errorMessage = "Could not reach GitHub. Check connection."
        return
    end if

    json = ParseJson(response)

    if json = invalid or type(json) <> "roArray"
        m.top.errorMessage = "Unexpected response from GitHub."
        return
    end if

    clips = []
    for each item in json
        name = LCase(item.name)
        if Right(name, 4) = ".mp4"
            clips.push(item.download_url)
        end if
    end for

    if clips.count() = 0
        m.top.errorMessage = "No .mp4 files found in repo."
        return
    end if

    m.top.clips = clips
end sub
